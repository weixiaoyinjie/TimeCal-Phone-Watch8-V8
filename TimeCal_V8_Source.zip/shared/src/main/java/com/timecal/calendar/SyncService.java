package com.timecal.calendar;
import com.google.android.gms.wearable.*;
public class SyncService extends WearableListenerService {
    @Override public void onDataChanged(DataEventBuffer events){Store s=new Store(this);for(DataEvent e:events)if(e.getType()==DataEvent.TYPE_CHANGED)s.receive(e.getDataItem());}
}
