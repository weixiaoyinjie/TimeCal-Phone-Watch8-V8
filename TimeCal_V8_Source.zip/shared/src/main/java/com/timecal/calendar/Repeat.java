package com.timecal.calendar;
import java.time.*;
import android.icu.util.Calendar;
final class Repeat {
    static final String[] KEYS={"none","daily","weekly","monthly","yearly","lunar"};
    static final String[] LABELS={"不重复","每天","每周","每月","每年·公历","每年·农历"};
    static int index(String key){for(int i=0;i<KEYS.length;i++)if(KEYS[i].equals(key))return i;return 0;}
    static String label(String key){return LABELS[index(key)];}
    static boolean solarMatches(LocalDate a,LocalDate d,String rule){
        if(d.isBefore(a))return false;
        switch(rule){case "daily":return true;case "weekly":return a.getDayOfWeek()==d.getDayOfWeek();case "monthly":return d.getDayOfMonth()==Math.min(a.getDayOfMonth(),d.lengthOfMonth());case "yearly":return d.getMonth()==a.getMonth()&&d.getDayOfMonth()==Math.min(a.getDayOfMonth(),d.lengthOfMonth());default:return a.equals(d);}
    }
    static boolean matches(LocalDate a,LocalDate d,String rule){
        if(!"lunar".equals(rule))return solarMatches(a,d,rule);
        if(d.isBefore(a))return false;
        Calendar x=Holidays.lunar(a),y=Holidays.lunar(d);
        if(x.get(Calendar.MONTH)!=y.get(Calendar.MONTH)||x.get(Calendar.IS_LEAP_MONTH)!=y.get(Calendar.IS_LEAP_MONTH))return false;
        return y.get(Calendar.DAY_OF_MONTH)==Math.min(x.get(Calendar.DAY_OF_MONTH),y.getActualMaximum(Calendar.DAY_OF_MONTH));
    }
}
